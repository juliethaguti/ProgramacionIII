<?php

class Archivo{
    
    static function Aniadir($contenido, $path){
        $archivo = fopen($path,'a');
        fwrite($archivo,json_encode($contenido).PHP_EOL);
        fclose($archivo);
    }
    
    static function Leer($path){
        $file=fopen($path,'r');
        $array = array();
        while(!feof($file)){
            //de string a objeto y lopaso a un array
            $linea = fgets($file);
            array_push($array,json_decode($linea));
        }
        //$contenido = fread($file,filesize($file));
        fclose($file);
        return $array;
    }

    static function Guardar($contenido, $file){
        $archivo = fopen($file,'w');
        foreach($contenido as $objeto){
            if($objeto != NULL){
                fwrite($archivo,json_encode($objeto).PHP_EOL);
            }
        }
        
        fclose($archivo);
    }

    static function Borrar($array){
        //echo $array[1]->nombre;
        unset($array[1]);
        return $array;
    }
    /*listar, borrar, cargar y modificar*/

    static function GuardarImagen($foto, $nombreFoto){
        //$origen = $foto["tmp_name"];
        $ext = array_reverse(explode(".",$foto->getClientFilename()));

        //move_uploaded_file($origen,"./Imagenes/".$nombreFoto.$ext[0]);
        $foto->moveTo('./images/pizzas/'.$nombreFoto.'.'.$ext[0]);
        return $nombreFoto.'.'.$ext[0];
    }
    static function SubirInformacion($ruta, $metodo){
        date_default_timezone_set('America/Argentina/Buenos_Aires');
        $hora= date('H:i:s');
        $contenido = $ruta.",".$metodo.",".$hora;
        Archivo::Aniadir($contenido,'info.log');
    }

    function backUp($registro){

        rename('./images/pizzas/'."$registro",'./images/backup/');
    }
}
?>