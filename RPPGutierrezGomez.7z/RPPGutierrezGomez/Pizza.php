<?php
require_once './Archivo.php';

class Pizza{
    public $precio;
    public $tipo;
    public $cantidad;
    public $sabor;
    public $fotoUno;
    public $fotoDos;
    public $id;

    function cargarPizzas($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();
        $files = $request->getUploadedFiles();

        $pizza = new stdclass;
        if(isset($ArrayParametros['precio']) && isset($ArrayParametros['cantidad'])){
            $pizza->precio = $ArrayParametros['precio'];
            $pizza->tipo = $ArrayParametros['tipo'];
            $pizza->cantidad = $ArrayParametros['cantidad'];
            $pizza->sabor = $ArrayParametros['sabor'];
            $pizza->id = Pizza::ObtenerId();

            if(Pizza::ValidarTipo($ArrayParametros['tipo'])){
                if(Pizza::ValidarSabor($ArrayParametros['sabor'])){
                    $nombreFotoUno= $ArrayParametros['tipo'].date("d-m");
                    $nombreFotoDos= $ArrayParametros['sabor'].date("d-m");
                    $foto = $files['fotoUno'];
                    $fotoDos = $files['fotoDos'];
                    $pizza->fotoUno = Archivo::GuardarImagen($foto,$nombreFotoUno);
                    $pizza->fotoDos = Archivo::GuardarImagen($fotoDos,$nombreFotoDos);

                    if(file_exists('Pizza.txt')){
                        $arrayPizzas=Archivo::Leer('Pizza.txt');
                        if(Pizza::ocurrenciasTipoSabor($arrayPizzas,$pizza->tipo,$pizza->sabor) < 0){
                            Archivo::Aniadir($pizza, 'Pizza.txt');
                            $newResponse = $response->withJson($pizza, 200);
                        }
                        else{
                            $newResponse = $response->write('ERROR: La combinacion tipo sabor ya está ingresada');
                        }
                    }
                    else{
                        Archivo::Aniadir($pizza, 'Pizza.txt');
                        $newResponse = $response->withJson($pizza, 200);
                    }
                }
                else{
                    $newResponse = $response->write('Ingrese un sabor correcto: muzza, jamon o especial');
                }
            }
            else{
                $newResponse = $response->write('Ingrese un tipo correcto: molde o piedra');
            }
        }
        else{
            $newResponse = $response->write('Uno o más datos no se pueden leer');
        }
             
        
        return $newResponse;
    }

    function consultarPizzas($request, $response, $args){
        $dato = $request->getQueryParams();

        $arrayPizzas = Archivo::Leer('Pizza.txt');
        
        $ocurrencias = 0;
        $ocurrenciasDos = 0;

        if(isset($dato["tipo"]) || isset($dato["sabor"])){
            for($i = 0; $i < count($arrayPizzas)-1; $i++){
                
                if(strcasecmp($dato["tipo"],$arrayPizzas[$i]->tipo) == 0){
                    $ocurrencias += $arrayPizzas[$i]->cantidad;
                }
                if(strcasecmp($dato["sabor"],$arrayPizzas[$i]->sabor) == 0){
                    $ocurrenciasDos+= $arrayPizzas[$i]->cantidad;
                }
            }
            
            if($ocurrencias == 0 && $ocurrenciasDos == 0){
                $newResponse = $response->write("No existe ni el tipo ni el sabor");
            }
            elseif($ocurrenciasDos != 0 && $ocurrencias != 0){
                $newResponse = $response->write("\nPizzas tipo ".$dato["tipo"].$ocurrencias." y ".$dato['sabor']." hay ".$ocurrenciasDos);
            }
            elseif($ocurrencias == 0 && $ocurrenciasDos != 0){
                $newResponse = $response->write("No existe ".$dato["tipo"]."pero hay ".$ocurrenciasDos.$dato['sabor']);
            }
            else{
                $newResponse = $response->write("No existe ".$dato["sabor"]."pero hay ".$ocurrencias.$dato["tipo"]);
            }
            
        }           
        
        return $response;
    }

    function modificarPizza($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();
        $files = $request->getUploadedFiles();
        //$files = $request->getBody();
        $fotoUno = $files['fotoUno'];
        $fotoDos = $files['fotoDos'];
        $nombreFotoUno= $ArrayParametros['tipo'].date("d-m");
        $nombreFotoDos= $ArrayParametros['sabor'].date("d-m");
        $tipo = $ArrayParametros['tipo'];
        $sabor = $ArrayParametros['sabor'];
        $cantidad = $ArrayParametros['cantidad'];
        $precio = $ArrayParametros['precio'];

        if(isset($tipo) || isset($sabor)){
             
            $list = Archivo::Leer('Pizza.txt');

            $auxArray = array();

            for($i = 0;$i < count($list)-1; $i++){
                if($list[$i]->sabor == $sabor && $list[$i]->tipo == $tipo){
                    $pizza = new stdclass;
                    if(isset($precio) && !empty($precio)){
                        $pizza->precio = $precio;
                    }
                    else{
                        $pizza->precio = $list[$i]->precio;
                    }
                    $pizza->tipo = $tipo;
                    if(isset($cantidad) && !empty($cantidad)){
                        $pizza->cantidad = $cantidad;
                    }
                    else{
                        $pizza->cantidad = $list[$i]->cantidad;
                    }
                    $pizza->sabor = $sabor;
                    $pizza->id = Pizza::ocurrenciasTipoSabor($list,$tipo,$sabor);
                    if(!empty($fotoUno)){
                        Archivo::backup($list[$i]->fotoUno);
                        //$pizza->fotoUno =  Archivo::GuardarImagen($fotoUno,$nombreFotoUno);
                    }
                    else{
                        $pizza->fotoUno = $list[$i]->fotoUno;
                    }
                    if(!empty($fotoDos)){
                        Archivo::backup($list[$i]->fotoDos);
                        var_dump($list[$i]->fotoDos);
                        //$pizza->fotoDos = Archivo::GuardarImagen($fotoDos,$nombreFotoDos);
                    }
                    else{
                        $pizza->fotoDos = $list[$i]->fotoDos;
                    }
                    
                }
                else{
                    $pizza = $list[$i];
                }    
                array_push($auxArray,$pizza);
            }
            
            $list = fopen("Pizza.txt", "w");
            fclose($list);
            var_dump($auxArray);
            /* foreach($auxArray as $p){
                Archivo::Aniadir($p,"Pizza.txt");
            } */
        }
        return $response;
    }

    static function borrarUno($request, $response, $args){
        $ArrayDeParametros = $request->getParsedBody();
        $id=$ArrayDeParametros['id'];
        $flag = 0;
        $list = Archivo::Leer('Pizza.txt');
        $auxArray = array();
        
        for($i = 0;$i < count($list)-1; $i++){
            if($list[$i]->id == $id){
                $flag = 1;
                continue;
            }
            else{
                $pizza = $list[$i];
                array_push($auxArray,$pizza);
            }
        }
        $file = fopen("Pizza.txt", "w");
            fclose($file);
            foreach($auxArray as $p){
                Archivo::Aniadir($p,"Pizza.txt");
            }
     	if($flag == 1){
            $newResponse = $response->write("Item borrado con exito");
         }
         else{
             $newResponse = $response->write("No existe el item");
         }
        return $newResponse;
    }

    static function ocurrenciasTipoSabor($list,$tipo,$sabor){
        $flag = -1;
        
        for($i = 0; $i < count($list)-1; $i++){
            if($list[$i]->sabor == $sabor && $list[$i]->tipo == $tipo){
                $flag = $list[$i]->id;
            }
        }
        return $flag;
    }

    static function ObtenerId(){
        $retorno = -1;

        if(file_exists('Pizza.txt')){
            $arrayPizzas = Archivo::Leer('Pizza.txt');
            
            for($i = 0; $i < count($arrayPizzas)-1; $i++){
                if(count($arrayPizzas)-2 == $i){
                    
                    $retorno = $arrayPizzas[$i]->id;  
                }
            }
        }
        return $retorno+1;
    }
    static function PizzasDisponibles($tipo, $sabor){
        $retorno = 0;
        if(file_exists('Pizza.txt')){
            $arrayPizzas = Archivo::Leer('Pizza.txt');

            for($i = 0; $i < count($arrayPizzas)-1; $i++){
                if($arrayPizzas[$i]->tipo ==$tipo && $arrayPizzas[$i]->sabor ==$sabor){
                    
                    $retorno = $arrayPizzas[$i]->cantidad;  
                }
            }
        }
        return $retorno;
    }

    static function DamePrecio($tipo,$sabor){
        $arrayPizzas = Archivo::Leer('Pizza.txt');
        $precio = 0;
        for($i = 0; $i < count($arrayPizzas)-1; $i++){
            if($arrayPizzas[$i]->tipo ==$tipo && $arrayPizzas[$i]->sabor ==$sabor){
                
                $precio = $arrayPizzas[$i]->precio;  
            }
        }
        return $precio;
    }
    static function DescontarPizzasVendidas($tipo, $sabor,$cantidad){
        $arrayPizzas = Archivo::Leer('Pizza.txt');
        for($i = 0; $i < count($arrayPizzas)-1; $i++){
            if($arrayPizzas[$i]->tipo ==$tipo && $arrayPizzas[$i]->sabor ==$sabor){
                
                $arrayPizzas[$i]->cantidad = $cantidad;  
            }
        }
        Archivo::Guardar($arrayPizzas,'Pizza.txt');
    }
    static function ValidarTipo($tipo){
        $retorno = false;

        $tipoToLower = strtolower($tipo);
        if($tipoToLower == "molde" || $tipoToLower == "piedra"){
            $retorno = true;
        }
        return $retorno;
    }
    static function ValidarSabor($sabor){
        $retorno = false;

        $saborToLower = strtolower($sabor);
        if($saborToLower == "muzza" || $saborToLower == "jamon" || $saborToLower == "especial"){
            $retorno = true;
        }
        return $retorno;
    }
    
}
?>