<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    var_dump($_FILES['Imagen']);
    $origen = $_FILES['Imagen']["tmp_name"];
    

    $ext = array_reverse(explode(".",$_FILES['Imagen']['name']));
    echo $ext[0];
    

    
    move_uploaded_file($origen,"./Imagenes/fot.".$ext[0]);
    //Primer parametro es el temp name de la imagen
    //Guardar funcion en una clase
}
?>
