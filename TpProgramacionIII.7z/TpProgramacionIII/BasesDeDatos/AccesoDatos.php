<?php
class AccesoDatos{
    private static $ObjetoAccesoDatos;
    private $objetoPDO;

    private function __construct(){
        try{
            $this->objetoPDO = new PDO('mysql:host=localhost;dbname=RestauranteDB;charset=utf8','root');
            $this->objetoPDO->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e){
            echo 'Falló la conexión: '.$e->getMessage();
        }
    }

    public function RetornarConsulta($sql){
        return $this->objetoPDO->prepare($sql);
    }

    public function RetornarUltimoInsertado(){
        return $this->objetoPDO->lastInsertId();
    }

    public static function dameUnObjetoAcceso(){
        if(!isset(self::$ObjetoAccesoDatos)){
            self::$ObjetoAccesoDatos = new AccesoDatos();
        }
        return self::$ObjetoAccesoDatos;
    }
}
?>