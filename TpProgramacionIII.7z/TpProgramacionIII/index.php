<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';

$config['displayErrorDetails'] = true; //Se habilita para poder obtener información sobre los errores.
$config['addContentLengthHeader'] = false; //Permite al servidor Web establecer el encabezado Content-Length, lo que hace que Slim se comporte de manera más predecible.

$app = new \Slim\App(["settings" => $config]);

$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");

    return $response;
});
$app->run();
?>