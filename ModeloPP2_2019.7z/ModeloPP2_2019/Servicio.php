<?php
require_once './Archivos.php';

class Vehiculo{
    public $id;
    public $tipo;
    public $precio;
    public $demora;

    function cargarTipoServicio($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();

        $servicio = new stdclass;
        $servicio->id = $ArrayParametros['id'];
        $servicio->tipo = $ArrayParametros['tipo'];
        $servicio->precio = $ArrayParametros['precio']; //La patente no puede ser repetida.
        $servicio->demora = $ArrayParametros['demora'];

        Archivo::Aniadir($servicio, 'tiposServicio.txt');        
        $newResponse = $response->withJson($servicio, 200);
        return $newResponse;
    }

}
?>