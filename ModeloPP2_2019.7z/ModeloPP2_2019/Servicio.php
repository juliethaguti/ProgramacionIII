<?php
require_once './Archivos.php';

class Servicio{

    public $id;
    public $tipo;
    public $precio;
    public $demora;

    function cargarTipoServicio($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();

        $servicio = new stdclass;
        $servicio->id = Servicio::ObtenerId();
        $servicio->tipo = $ArrayParametros['tipo'];
        $servicio->precio = $ArrayParametros['precio']; 
        $servicio->demora = $ArrayParametros['demora'];

        Archivo::Aniadir($servicio, 'tiposServicio.txt');        
        $newResponse = $response->withJson($servicio, 200);
        return $newResponse;
    }

    function sacarTurno($request, $response, $args){
        $parametros = $request->getQueryParams();
        $arrayServicios = Archivo::Leer('tiposServicio.txt');
        $vehiculo = new stdclass;
        $servicio = new stdclass;
        $patente = $parametros['patente'];
        $fecha = $parametros['fecha'];

        $vehiculo=Vehiculo::BuscarVehiculo($patente);
        $servicio = Servicio::DameServicio(); 

        $turno = new stdclass;
        $turno->fecha = $fecha;
        $turno->patente = $patente;
        $turno->marca = $vehiculo->marca;
        $turno->modelo = $vehiculo->modelo;
        $turno->precio= $vehiculo->precio;
        $turno->tipoServicio = $servicio->tipo;
        
        if(Servicio::DameCupo() && Servicio::DameMateria()){
            Archivo::Aniadir($turno, 'turnos.txt');
            $newResponse = $response->write("Tiene cupo la patente ".$patente." en la fecha ".$fecha);
        }
        elseif(Servicio::DameCupo() && !Servicio::DameMateria()){
            $newResponse = $response->write("No hay cupo para el dia ".$fecha);
        }
        elseif(Servicio::DameCupo() && Servicio::DameMateria()){
            $newResponse = $response->write("No hay materia para asignar el turno");
        }
        else{
            $newResponse = $response->write("No hay cupo ni materia");
        }
        return $newResponse;
    }

    function turnos($request, $response, $args){
        $arrayTurnos=Archivo::Leer('turnos.txt');
        
        $tabla = "<table  border= '1' border-collapse='collapse'  width=100%>
        <caption>Lista de turnos</caption>
        <thead>
            <tr>        
                <th>Fecha</th>
                <th>Patente</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Precio</th>
                <th>Tipo de Servicio</th>
            </tr>
        </thead>
        <tbody>";
        
        for($i = 0; $i <count($arrayTurnos)-1;$i++){
            $fecha = $arrayTurnos[$i]->fecha;
            $patente = $arrayTurnos[$i]->patente;
            $marca = $arrayTurnos[$i]->marca;
            $modelo = $arrayTurnos[$i]->modelo;
            $precio = $arrayTurnos[$i]->precio;
            $tipo = $arrayTurnos[$i]->tipoServicio;
            
            $tabla .="<tr>
                <td>$fecha</td>
                <td>$patente</td>
                <td>$marca</td>
                <td>$modelo</td>
                <td>$precio</td>
                <td>$tipo</td>
            </tr>";
        }
        $tabla .= "</tbody>
        </table>";
        echo ($tabla);
    }

    function inscripciones($request, $response, $args){
        $parametros = $request->getQueryParams();

        $parametroTipo = $parametros['tipo'];
        $parametreoFecha = $parametros['fecha'];

        $arrayTurnos=Archivo::Leer('turnos.txt');
        
        $tabla = "<table  border= '1' border-collapse='collapse'  width=100%>
        <caption>Lista de turnos</caption>
        <thead>
            <tr>        
                <th>Fecha</th>
                <th>Patente</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Precio</th>
                <th>Tipo de Servicio</th>
            </tr>
        </thead>
        <tbody>";
        
        for($i = 0; $i <count($arrayTurnos)-1;$i++){
            $fecha = $arrayTurnos[$i]->fecha;
            $tipo = $arrayTurnos[$i]->tipoServicio;
            $marca = $arrayTurnos[$i]->marca;
            $modelo = $arrayTurnos[$i]->modelo;
            $precio = $arrayTurnos[$i]->precio;
            $patente = $arrayTurnos[$i]->patente;

            if($parametreoFecha == $fecha){
            
            $tabla .="<tr>
                <td>$fecha</td>
                <td>$patente</td>
                <td>$marca</td>
                <td>$modelo</td>
                <td>$precio</td>
                <td>$tipo</td>
            </tr>";
        }
        elseif($parametroTipo == $tipo){
            
            $tabla .="<tr>
                <td>$fecha</td>
                <td>$patente</td>
                <td>$marca</td>
                <td>$modelo</td>
                <td>$precio</td>
                <td>$tipo</td>
            </tr>";
        }            
    }    
    $tabla .= "</tbody>
    </table>";
    echo ($tabla);
}

    static function ObtenerId(){
        $retorno = -1;

        if(file_exists('tiposServicio.txt')){
            $arrayServicios = Archivo::Leer('tiposServicio.txt');
            
            for($i = 0; $i < count($arrayServicios)-1; $i++){
                if(count($arrayServicios)-2 == $i){
                    
                    $retorno = $arrayServicios[$i]->id;  
                }
            }
        }
        return $retorno+1;
    }

    static function DameServicio(){
        $id = rand(0,2);
        //$retorno = new stdclass;
        $arrayServicios=Archivo::Leer('tiposServicio.txt');
        
        for($i = 0; $i < 3; $i++){
            if($arrayServicios[$i]->id == 0){
                $retorno = $arrayServicios[$i];
            }
            elseif($arrayServicios[$i]->id ==2){
                $retorno = $arrayServicios[$i];
            }
            elseif($arrayServicios[$i]->id == 3){
                $retorno = $arrayServicios[$i];
            } 
        }
        
        return $retorno;
     }

     static function DameMateria(){
         return rand(0,1);
     }

     static function DameCupo(){
        return rand(0,1);
     }
}
?>