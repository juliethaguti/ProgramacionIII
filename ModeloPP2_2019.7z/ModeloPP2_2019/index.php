<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
//composer require slim/slim "^3.12"

require 'vendor/autoload.php';
require_once './Vehiculo.php';
require_once './Servicio.php';

$config['addContentLenghtHeader'] = false;
$config['displayErrorDetails'] = true;

$app = new \Slim\App(['settings' => $config]);

$app->group('/vehiculos',function(){
    $this->get('[/]', \Vehiculo::class . ':consultarVehiculo');
    $this->post('/', \Vehiculo::class . ':cargarVehiculo');
    $this->post('/modificar', \Vehiculo::class . ':modificarVehiculo');
    $this->get('/mostrar', \Vehiculo::class . ':mostrarVehiculos');
});

$app->group('/servicio',function(){
    $this->get('[/]', \Servicio::class . ':sacarTurno');
    $this->post('/', \Servicio::class . ':cargarTipoServicio');
    $this->get('/turnos', \Servicio::class . ':turnos');
    $this->get('/tabla', \Servicio::class . ':inscripciones');
});

$app->run();
?>