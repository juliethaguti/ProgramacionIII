<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';
require_once './Vehiculo.php';
require_once './Servicio.php';

$config['addContentLenghtHeader'] = false;
$config['displayErrorDetails'] = true;

$app = new \Slim\App(['settings' => $config]);

$app->group('/vehiculos',function(){
    $this->get('[/]', \Vehiculo::class . ':consultarVehiculo');
    $this->post('/', \Vehiculo::class . ':cargarVehiculo');
});

$app->group('/servicio',function(){
    $this->get('[/]', \Vehiculo::class . ':consultarVehiculo');
    $this->post('/', \Vehiculo::class . ':cargarTipoServicio');
});

$app->run();
?>