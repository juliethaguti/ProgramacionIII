<?php
require_once './Archivos.php';

class Vehiculo{
    public $marca;
    public $modelo;
    public $patente;
    public $precio;

    function cargarVehiculo($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();

        $vehiculo = new stdclass;
        $vehiculo->marca = $ArrayParametros['marca'];
        $vehiculo->modelo = $ArrayParametros['modelo'];
        $vehiculo->patente = $ArrayParametros['patente']; //La patente no puede ser repetida.
        $vehiculo->precio = $ArrayParametros['precio'];

        Archivo::Aniadir($vehiculo, 'vehiculo.txt');        
        $newResponse = $response->withJson($vehiculo, 200);
        return $newResponse;
    }

    function consultarVehiculo($request, $response, $args){
        $dato = $request->getQueryParams();
        //localhost:80/ModeloPP2_2019/vehiculos/?marca=jeep
        $arrayVehiculos = Archivo::Leer('vehiculo.txt');
        
        $ocurrencias = 0;

        if(isset($dato["marca"])){
            for($i = 0; $i < 2; $i++){
                
                if($dato["marca"] == $arrayVehiculos[$i]->marca){
                    $ocurrencias++;
                    
                    //imprimir
                }
            }
            if($ocurrencias == 0){
                $newResponse = $response->write("No existe ".$dato["marca"]);
            }
            else{
                $newResponse = $response->write($ocurrencias);
            }
        }
        elseif(isset($dato["modelo"])){
            foreach($arrayVehiculos as $vehiculo){
                if($dato["modelo"] == $vehiculo->modelo){
                    $ocurrencias++;
                }
            }
            if($ocurrencias == 0){
                $newResponse = $response->write("No existe ".$dato["modelo"]);
            }
        }
        elseif(isset($dato["patente"])){
            foreach($arrayVehiculos as $vehiculo){
                if($dato["patente"] == $vehiculo->patente){
                    $ocurrencias++;
                }
            }
            if($ocurrencias == 0){
                $newResponse = $response->write("No existe ".$dato["patente"]);
            }
        }
        return $response;
    }

    
}
?>