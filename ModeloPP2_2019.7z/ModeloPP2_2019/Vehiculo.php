<?php
require_once './Archivos.php';

class Vehiculo{
    public $marca;
    public $modelo;
    public $patente;
    public $precio;
    public $foto;

    function cargarVehiculo($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();

        $vehiculo = new stdclass;
        $vehiculo->marca = $ArrayParametros['marca'];
        $vehiculo->modelo = $ArrayParametros['modelo'];
        $vehiculo->patente = $ArrayParametros['patente']; //La patente no puede ser repetida.
        $vehiculo->precio = $ArrayParametros['precio'];

        if(!Vehiculo::BuscarPatente($vehiculo->patente)){
            Archivo::Aniadir($vehiculo, 'vehiculo.txt');
            $newResponse = $response->withJson($vehiculo, 200);
        }
        else{
            $newResponse = $response->write('ERROR: La patente ya está ingresada');
        }     
        
        return $newResponse;
    }

    function consultarVehiculo($request, $response, $args){
        $dato = $request->getQueryParams();
        //localhost:80/ModeloPP2_2019/vehiculos/?marca=jeep
        $arrayVehiculos = Archivo::Leer('vehiculo.txt');
        
        $ocurrencias = 0;

        if(isset($dato["marca"])){
            for($i = 0; $i < count($arrayVehiculos)-1; $i++){
                
                if(strcasecmp($dato["marca"],$arrayVehiculos[$i]->marca) == 0){
                    $ocurrencias++;
                    $newResponse = $response->write("\nMarca: ".$arrayVehiculos[$i]->marca." Modelo: ".$arrayVehiculos[$i]->modelo." Patente: ".$arrayVehiculos[$i]->patente." Precio: ".$arrayVehiculos[$i]->precio."\n");
                }
            }
            if($ocurrencias == 0){
                $newResponse = $response->write("No existe ".$dato["marca"]);
            }
        }
        elseif(isset($dato["modelo"])){
            for($i = 0; $i < count($arrayVehiculos)-1; $i++){
                if($dato["modelo"] == $arrayVehiculos[$i]->modelo){
                    $ocurrencias++;
                    $newResponse = $response->write("\nMarca: ".$arrayVehiculos[$i]->marca." Modelo: ".$arrayVehiculos[$i]->modelo." Patente: ".$arrayVehiculos[$i]->patente." Precio: ".$arrayVehiculos[$i]->precio."\n");
                }
            }
            if($ocurrencias == 0){
                $newResponse = $response->write("No existe ".$dato["modelo"]);
            }
        }
        elseif(isset($dato["patente"])){
            for($i = 0; $i < count($arrayVehiculos)-1; $i++){
                if(strcasecmp($dato["patente"],$arrayVehiculos[$i]->patente) == 0){
                    $ocurrencias++;
                    $newResponse = $response->write("\nMarca: ".$arrayVehiculos[$i]->marca." Modelo: ".$arrayVehiculos[$i]->modelo." Patente: ".$arrayVehiculos[$i]->patente." Precio: ".$arrayVehiculos[$i]->precio."\n");
                }
            }
            if($ocurrencias == 0){
                $newResponse = $response->write("No existe ".$dato["patente"]);
            }
        }
        return $response;
    }

    function modificarVehiculo($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();
        $files = $request->getUploadedFiles();

        $vehiculo = new stdclass;
        $vehiculo->marca = $ArrayParametros['marca'];
        $vehiculo->modelo = $ArrayParametros['modelo'];
        $vehiculo->patente = $ArrayParametros['patente']; 
        $vehiculo->precio = $ArrayParametros['precio'];
        $nombreFoto= $ArrayParametros['patente'].date("d-m");
        $foto = $files['foto'];
        $vehiculo->foto = Archivo::GuardarImagen($foto,$nombreFoto);

        $vehiculoEncontrado = Vehiculo::BuscarPatente($vehiculo->patente);
        $arrayVehiculos = Archivo::Leer('vehiculo.txt');
        
        unset($arrayVehiculos[$vehiculoEncontrado]);
        Archivo::Guardar($arrayVehiculos, 'vehiculo.txt');
        Archivo::Aniadir($vehiculo,'vehiculo.txt');
        return $response;
    }

    function mostrarVehiculos($request, $response, $args){
        $arrayVehiculos=Archivo::Leer('vehiculo.txt');
        
        $tabla = "<table  border= '1' border-collapse='collapse'  width=100%>
        <caption>Lista de turnos</caption>
        <thead>
            <tr>
                <th>Patente</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Precio</th>
                <th>Foto</th>
            </tr>
        </thead>
        <tbody>";
        
        for($i = 0; $i <count($arrayVehiculos)-1;$i++){
            $patente = $arrayVehiculos[$i]->patente;
            $marca = $arrayVehiculos[$i]->marca;
            $modelo = $arrayVehiculos[$i]->modelo;
            $precio = $arrayVehiculos[$i]->precio;
            $foto = $arrayVehiculos[$i]->foto;
            
            $tabla .="<tr>
                <td>$patente</td>
                <td>$marca</td>
                <td>$modelo</td>
                <td>$precio</td>
                <td><img style='width: 50px; height: 50px;' src='./fotos/$foto'></td>
            </tr>";
        }
        $tabla .= "</tbody>
        </table>";
        echo ($tabla);
    }
    static function BuscarPatente($patente){
        $arrayVehiculos = Archivo::Leer('vehiculo.txt');
        $retorno = 0;

        for($i = 0; $i < count($arrayVehiculos)-1; $i++){
            if($arrayVehiculos[$i]->patente == $patente){
                $retorno = $i;
            }
        }
        return $retorno;
    }

    static function BuscarVehiculo($patente){
        $vehiculo = new stdclass;
        $arrayVehiculos=Archivo::Leer('vehiculo.txt');

        for($i = 0; $i < count($arrayVehiculos)-1; $i++){
            if($arrayVehiculos[$i]->patente == $patente){
                $vehiculo = $arrayVehiculos[$i];
            }
        }
        return $vehiculo;
    }
    
}
?>