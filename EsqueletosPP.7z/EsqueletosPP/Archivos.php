<?php
class Archivo{
    private $path;

    function __construct($path){
        $this->path = $path;
    }
    function Añadir($contenido){
        $archivo = fopen($this->path,'a');
        fwrite($archivo,json_encode($contenido).PHP_EOL);
        fclose($archivo);
    }
    
    function Leer(){
        $file=fopen($this->path,'r');
        $array = array();
        while(!feof($file)){
            //de string a objeto y lopaso a un array
            $linea = fgets($file);
            array_push($array,json_decode($linea));
        }
        //$contenido = fread($file,filesize($file));
        fclose($file);
        return $array;
    }

    function Guardar($contenido){
        $archivo = fopen($file,'w');
        foreach($contenido as $objeto){
            fwrite($archivo,json_encode($objeto).PHP_EOL);
        }
        
        fclose($archivo);
    }

    function Borrar($array){
        //echo $array[1]->nombre;
        unset($array[1]);
        return $array;
    }
    /*listar, borrar, cargar y modificar*/

    static function GuardarImagen($foto, $nombreFoto){
        $origen = $foto["tmp_name"];
        $ext = array_reverse(explode(".",$foto['name']));
        echo $ext[0];

        move_uploaded_file($origen,"./Imagenes/".$nombreFoto.$ext[0]);

        return $nombreFoto.$ext[0];
    }
}
?>