<?php
require_once './Archivos.php';

//Archivos
$nuevoArchivo = new Archivo('nuevoArchivo.txt');

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $foto = $_FILES['imagen'];
    $legajo = $_POST['legajo'];
    $nombreFotoNueva = $legajo."_Foto";

    $retorno = Archivo::GuardarImagen($foto,$nombreFotoNueva);
    echo $retorno;
    $obj= array("nombre"=>$nombre,"apellido"=>$apellido,"legajo"=>$legajo,"foto"=>$foto);
    $nuevoArchivo->Añadir($obj);
    //$array = $nuevoArchivo->Leer();

    //$nuevoArray = $nuevoArchivo->Borrar($array);
    //$nuevoArchivo->Guardar("nuevoArchivo.txt",$nuevoArray);
    //$nuevoArchivo->GuardarImagen($foto,"./Imagenes/".$nombreFotoNueva);
}

if($_SERVER['REQUEST_METHOD'] == 'GET'){
    var_dump($nuevoArchivo->Leer());
}
?>