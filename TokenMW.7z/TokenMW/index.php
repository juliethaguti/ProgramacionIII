<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Firebase\JWT\JWT;

require './vendor/autoload.php';

$config['addContentLenghtHeader'] = false;
$config['displayErrorDetails'] = true;

$app = new \Slim\App(['settings' => $config]);

$app->group('/token',function(){
    $this->post('/login',function($req,$res, $args =[]){
        $body = $req->getParsedBody();

        $secret_key = 'Sdw1s9x8@';

        $time = time();
        $token = array(
            'exp' => $time + (60*60),
            'user' => $body['user']
        );
        $jwt = JWT::encode($token, $secret_key);
        //$newResponse = $res->withJson($jwt, 200);
        return $res->getBody()->write($jwt);
    })->add(function($request, $response, $next){
        $response->getBody()->write('Antes <br>');
        $response = $next($request, $response);
        $response->getBody()->write('<br>Despues');
    
        return $response;
    });

    $this->get('[/]',function($req,$res){
        $secret_key = 'Sdw1s9x8@';
        $encrypt = ['HS256'];

        $token = $req->getHeader("token")[0];
        $decode =JWT::decode(
            $token,
            $secret_key,
            $encrypt
        );
        $newResponse = $res->withJson($decode, 200);
        return $newResponse;
    });
})->add(function($request, $response, $next){
    $response->getBody()->write('Primero <br>');
    $response = $next($request, $response);
    $response->getBody()->write('<br>Segundo');

    return $response;
});

$app->run();
?>