<?php

require_once './Archivos.php';

$nuevoArchivo = new Archivo('nuevoArchivo.txt');
/* $file=fopen("archivo.txt",'a');
fwrite($file,"Escribo el archivo".PHP_EOL);
fclose($file);

$file=fopen("archivo.txt",'r');

echo fread($file,filesize("archivo.txt")); */

//Fread -> Lee todo el archivo
//copy("archivo.txt","archivo2.txt");
//unlink("archivo2.txt");
//copy -> copia archivo
//unlink borra el archivo
//php_eol SAlto de linea
/*fclose($file);*/

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //$obj= array("nombre"=>$_POST['nombre'],"apellido"=>$_POST['apellido']);
    $foto = $_FILES['imagen'];
    $nombreFotoNueva;
$array = $nuevoArchivo->Leer();

$nuevoArray = $nuevoArchivo->Borrar($array);
var_dump($nuevoArray);
$nuevoArchivo->Guardar("nuevoArchivo.txt",$nuevoArray);
$nuevoArchivo->GuardarImagen($foto,"./Imagenes/".$nombreFotoNueva)
}

if($_SERVER['REQUEST_METHOD'] == 'GET'){
    var_dump($nuevoArchivo->Leer());
}
//Archivo::Guardar("nuevoArchivo.txt","Lo que quiero guardar");
/*En Guardar: recibir las variavle y poner las variables en un array, concatenar la coma y mas adelante los corchetes para leerlo para que sea formato json válido.
$obj = array("nombre"=>$_get['nombre']):
$ar=fopen("objetos.json",'a');
fwrite($ar,','.jsonencode($obj));

fclose($ar);*/
/*Para leer: $ar = fopen (archivo,modo);
while(!feof($ar)){
    //de string a objeto y lopaso a un array
    fgets($ar).'<br>';
}
fclose($ar);*/
?>