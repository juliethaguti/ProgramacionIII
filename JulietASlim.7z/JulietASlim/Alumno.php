<?php
require_once './Archivos.php';

class Alumno{

    public $nombre;
    public $apellido;
    //public $archivo = new Archivo('alumnos.txt');

    function __construct(){
    }

    static function TraerTodos(){

    }

     public static function CargarUno($request, $response, $args){
        $ArrayParametros = $request->getParsedBody();

        $alumno = new stdclass;
        $alumno->nombre = $ArrayParametros['nombre'];
        $alumno->apellido = $ArrayParametros['apellido'];
        Archivo::Aniadir($alumno, 'alumno.txt');        
        $newResponse = $response->withJson($alumno, 200);
        return $newResponse;
    }
}
?>