<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';
require_once './Alumno.php';

$config['addContentLenghtHeader'] = false;
$config['displayErrorDetails'] = true;

$app = new \Slim\App(['settings' => $config]);

$app->group('/alumnos',function(){
    $this->get('/', \Alumno::class . ':TraerTodos');
    $this->post('/', \Alumno::class . ':CargarUno');
});

$app->run();
?>