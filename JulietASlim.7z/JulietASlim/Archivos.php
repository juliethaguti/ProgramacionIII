<?php
class Archivo{
    /*private $path;

    function __construct($path){
        $this->path = $path;
    }*/
    static function Aniadir($contenido, $path){
        $archivo = fopen($path,'a');
        fwrite($archivo,json_encode($contenido).PHP_EOL);
        fclose($archivo);
    }
    
    static function Leer(){
        $file=fopen($this->path,'r');
        $array = array();
        while(!feof($file)){
            //de string a objeto y lopaso a un array
            $linea = fgets($file);
            array_push($array,json_decode($linea));
        }
        //$contenido = fread($file,filesize($file));
        fclose($file);
        return $array;
    }

    static function Guardar($file, $contenido){
        $archivo = fopen($file,'w');
        foreach($contenido as $objeto){
            if($objeto != NULL){
                fwrite($archivo,json_encode($objeto).PHP_EOL);
            }
        }
        
        fclose($archivo);
    }

    static function Borrar($array){
        //echo $array[1]->nombre;
        unset($array[1]);
        return $array;
    }
    /*listar, borrar, cargar y modificar*/

    static function GuardarImagen($foto, $nombreFoto){
        $origen = $foto["tmp_name"];
        $ext = array_reverse(explode(".",$foto['name']));
        echo $ext[0];

        move_uploaded_file($origen,"./Imagenes/".$nombreFoto.$ext[0]);

        return $nombreFoto.$ext[0];
    }
}
?>