<?php
namespace App\Models\ORM;
use App\Models\ORM\usuario;//ruta completa de la clase
use App\Models\AutentificadorJWT;

class MWParaAutentificar
{
    public function VerificarAdmin($request, $response, $next) {
        $token = $request->getHeader('token');
        $payload = AutentificadorJWT::ObtenerData($token[0]);
        //var_dump($payload);
        if($payload->tipo == "admin")
        {
            $response = $next($request, $response);
        }		           	
        else
        {
            $response=$response->withJson("Solo administradores", 401);	
        }
        return $response;            
    }

    public function VerificarUsuario($request, $response, $next){
        $token = $request->getHeader('token');
        if(empty($token)|| $token == ''){
            throw new Exception("El token esta vacio.");
        }
        else{
            $payload = AutentificadorJWT::ObtenerData($token[0]);
            if($payload->legajo < 101){
                $request = $request->withAttribute('legajo', $payload->legajo);
                $response = $next($request, $response);
            }else{
                $response=$response->withJson("Solo administradores", 401);
            }
        }
        
        return $response;
    }

    public function VerificarAcceso($request, $response, $next){
        $token = $request->getHeader('token');
        if(empty($token)|| $token == ''){
            throw new Exception("El token esta vacio.");
        }
        else{
            $payload = AutentificadorJWT::ObtenerData($token[0]);
            if($payload->legajo > 0 && $payload->legajo < 1001){
                $request = $request->withAttribute('legajo', $payload->legajo);
                $response = $next($request, $response);
            }else{
                $response=$response->withJson("Acceso prohibido", 401);
            }
        }
        
        return $response;
    }
}
?>