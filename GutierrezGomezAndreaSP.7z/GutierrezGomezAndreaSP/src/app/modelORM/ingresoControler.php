<?php
namespace App\Models\ORM;
use App\Models\ORM\ingreso;
use App\Models\IApiControler;
use App\Models\AutentificadorJWT;

include_once __DIR__ . '/ingreso.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class ingresoControler implements IApiControler 
{
 	public function TraerTodos($request, $response, $args) {
        $legajo = $request->getAttribute('legajo');
        $usuario = usuario::find($legajo);
        $email = $usuario->email;
        $todosLosIngresos = ingreso::where('email',$email)->get();

        $newResponse = $response->withJson($todosLosIngresos, 200);  
        return $newResponse;
    }
    public function TraerUno($request, $response, $args) {
        $legajo = $request->getAttribute('legajo');
        $usuario = usuario::find($legajo);
        $email = $usuario->email;
        $lastIngreso = ingreso::all();
     	$newResponse = $response->withJson($lastIngreso, 200);  
    	return $newResponse;
    }
   
      public function CargarUno($request, $response, $args) {
        $legajo = $request->getAttribute('legajo');
        $usuario = usuario::find($legajo);
        $email = $usuario->email;
        $ingreso = new ingreso;
        $emailIngresado = ingreso::where('email',$email)->get();
        if($emailIngresado->isEmpty()){
            $ingreso->hora = date('h-M');
            $ingreso->email = $email;
            $ingreso->save();
            $newResponse = $response->withJson('ingreso exitoso', 200);
        }
        else{
        $newResponse = $response->withJson('El ûsuario ya ingreso', 200);
        }
        return $newResponse;
    }
      public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
     public function ModificarUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
		return 	$newResponse;
    }

    }