<?php
namespace App\Models\ORM;
use App\Models\ORM\egreso;
use App\Models\IApiControler;

include_once __DIR__ . '/egreso.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class egresoControler implements IApiControler 
{
 	public function Beinvenida($request, $response, $args) {
      $response->getBody()->write("GET => Bienvenido!!! ,a UTN FRA SlimFramework");
    
    return $response;
    }
    
     public function TraerTodos($request, $response, $args) {
       	//return cd::all()->toJson();
        $todosLosCds=cd::all();
        $newResponse = $response->withJson($todosLosCds, 200);  
        return $newResponse;
    }
    public function TraerUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
    	return $newResponse;
    }
   
      public function CargarUno($request, $response, $args) {
        $legajo = $request->getAttribute('legajo');
        $usuario = usuario::find($legajo);
        $email = $usuario->email;
        $egreso = new egreso;
        $emailIngresado = egreso::where('email',$email)->get();
        
            $ingreso = ingreso::where('email',$email)->get();
            if($ingreso->isEmpty()){
                $newResponse = $response->withJson('El usuario no ha ingresado', 200);    
            }
            else{
                $egreso->hora = date('h-M');
                $egreso->email = $email;
                $egreso->save();
                $ingresoABorrar = ingreso::where('email',$email)->delete();
                $newResponse = $response->withJson('egreso exitoso', 200);
            }
            
        
        return $newResponse;
    }
      public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
     public function ModificarUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
		return 	$newResponse;
    }


  
}