<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\usuario;
use App\Models\ORM\usuarioControler;
use App\Models\ORM\MWParaAutentificar;
use App\Models\ORM\ingreso;
use App\Models\ORM\ingresoControler;
use App\Models\ORM\egreso;
use App\Models\ORM\egresoControler;

include_once __DIR__ . '/../../src/app/modelAPI/MWParaAutentificar.php';
include_once __DIR__ . '/../../src/app/modelORM/usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/usuarioControler.php';
include_once __DIR__ . '/../../src/app/modelORM/ingreso.php';
include_once __DIR__ . '/../../src/app/modelORM/ingresoControler.php';
include_once __DIR__ . '/../../src/app/modelORM/egreso.php';
include_once __DIR__ . '/../../src/app/modelORM/egresoControler.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/users', function () {   

      $this->post('/',usuarioControler::class . ':CargarUno');
      $this->post('/login',usuarioControler::class . ':Login');
      $this->put('/ingreso',ingresoControler::class . ':CargarUno')->add(MWParaAutentificar::class . ':VerificarAcceso');
      $this->put('/egreso',egresoControler::class . ':CargarUno')->add(MWParaAutentificar::class . ':VerificarAcceso');
      $this->get('/ingreso',ingresoControler::class . ':TraerTodos')->add(MWParaAutentificar::class . ':VerificarAcceso');
      $this->get('/lastingreso',ingresoControler::class . ':TraerTodos')->add(MWParaAutentificar::class . ':VerificarUsuario');
  });

};