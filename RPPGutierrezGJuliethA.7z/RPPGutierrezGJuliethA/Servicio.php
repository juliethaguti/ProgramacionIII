<?php
require_once './Archivo.php';

class Servicio{

    public $id;
    public $tipo;
    public $precio;
    public $demora;

function __construct($id,$tipo,$precio,$demora){
    $this->tipo = $tipo;
    $this->precio = $precio;
    $this->demora = $demora;
    $this->id = $id;
}
static function sacarTurno($arrayServicios,$vehiculo,$fecha,$patente){
    //$vehiculo = new stdclass;
    //$servicio = new stdclass;
    $archivoTurnos = new Archivo('turnos.txt');
    $servicio = Servicio::DameServicio($arrayServicios); 

    $turno = new stdclass;
    $turno->fecha = $fecha;
    $turno->patente = $patente;
    $turno->marca = $vehiculo->marca;
    $turno->tipoServicio = $servicio->tipo;
    
    if(Servicio::DameCupo() && Servicio::DameMateria()){
        $archivoTurnos->addObject($turno);
        echo("Tiene cupo la patente ".$patente." en la fecha ".$fecha);
    }
    elseif(Servicio::DameCupo() && !Servicio::DameMateria()){
        echo("No hay cupo para el dia ".$fecha);
    }
    elseif(Servicio::DameCupo() && Servicio::DameMateria()){
        echo("No hay materia para asignar el turno");
    }
    else{
        echo("No hay cupo ni materia");
    }
}
static function turnos($arrayTurnos){
    $arrayTurnos=Archivo::Leer('turnos.txt');
    
    $tabla = "<table  border= '1' border-collapse='collapse'  width=100%>
    <caption>Lista de turnos</caption>
    <thead>
        <tr>        
            <th>Fecha</th>
            <th>Patente</th>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Precio</th>
            <th>Tipo de Servicio</th>
        </tr>
    </thead>
    <tbody>";
    
    for($i = 0; $i <count($arrayTurnos)-1;$i++){
        $fecha = $arrayTurnos[$i]->fecha;
        $patente = $arrayTurnos[$i]->patente;
        $marca = $arrayTurnos[$i]->marca;
        $modelo = $arrayTurnos[$i]->modelo;
        $precio = $arrayTurnos[$i]->precio;
        $tipo = $arrayTurnos[$i]->tipoServicio;
        
        $tabla .="<tr>
            <td>$fecha</td>
            <td>$patente</td>
            <td>$marca</td>
            <td>$modelo</td>
            <td>$precio</td>
            <td>$tipo</td>
        </tr>";
    }
    $tabla .= "</tbody>
    </table>";
    echo ($tabla);
}

static function ObtenerId($arrayVentas){
    $retorno = -1;
  
        for($i = 0; $i < count($arrayVentas)-1; $i++){
            if(count($arrayVentas)-2 == $i){
                
                $retorno = $arrayVentas[$i]->id;  
            }
        }
        return $retorno+1;
    }

    static function ValidarTipo($tipo){
        $retorno = false;
    
        if($tipo == "10000Km" || $tipo == "20000Km" || $tipo == "30000Km"){
            $retorno = true;
        }
        return $retorno;
    }
    static function DameServicio($arrayServicios){
        $id = rand(0,2);
        
        for($i = 0; $i < 3; $i++){
            if($arrayServicios[$i]->id == 0){
                $retorno = $arrayServicios[$i];
            }
            elseif($arrayServicios[$i]->id ==2){
                $retorno = $arrayServicios[$i];
            }
            elseif($arrayServicios[$i]->id == 3){
                $retorno = $arrayServicios[$i];
            } 
        }
        
        return $retorno;
     }
     static function DameMateria(){
        return rand(0,1);
    }
    static function DameCupo(){
        return rand(0,1);
     }
}
?>