<?php
require_once './Archivo.php';

class Vehiculo{
    public $marca;
    public $patente;
    public $kms;

    function __construct($marca,$patente,$kms){
        $this->marca = $marca;
        $this->patente = $patente;
        $this->kms = $kms;
    }

    static function BuscarPatente($patente,$arrayVehiculos){
        $retorno = 0;

        for($i = 0; $i < count($arrayVehiculos)-1; $i++){
            if($arrayVehiculos[$i]->patente == $patente){
                $retorno = $i;
            }
        }
        return $retorno;
    }
    static function consultarVehiculo($arrayVehiculos,$marca,$patente){           
        
        $ocurrencias = 0;
        
        if(isset($marca) && empty($patente)){
            for($i = 0; $i < count($arrayVehiculos)-1; $i++){
                if(strcasecmp($marca,$arrayVehiculos[$i]->marca) == 0){
                    $ocurrencias++;
                    echo("\nMarca: ".$arrayVehiculos[$i]->marca." Patente: ".$arrayVehiculos[$i]->patente." Kms: ".$arrayVehiculos[$i]->kms."\n");
                }
            }
            if($ocurrencias == 0){
                echo("No existe ".$marca);
            }
        }
        elseif(isset($patente) && empty($marca)){
            
            for($i = 0; $i < count($arrayVehiculos)-1; $i++){
                if(strcasecmp($patente,$arrayVehiculos[$i]->patente) == 0){
                    $ocurrencias++;
                    echo("\nMarca: ".$arrayVehiculos[$i]->marca." Patente: ".$arrayVehiculos[$i]->patente." Kms: ".$arrayVehiculos[$i]->kms."\n");
                }
            }
            if($ocurrencias == 0){
                echo("No existe ".$patente);
            }
        }
    }
    static function BuscarVehiculo($patente,$arrayVehiculos){
        $vehiculo = new stdclass;

        for($i = 0; $i < count($arrayVehiculos)-1; $i++){
            if($arrayVehiculos[$i]->patente == $patente){
                $vehiculo = $arrayVehiculos[$i];
            }
        }
        return $vehiculo;
    }
}
    ?>