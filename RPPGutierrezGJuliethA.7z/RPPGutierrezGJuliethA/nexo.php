<?php
include_once('Archivo.php');
include_once('Vehiculo.php');
include_once('Servicio.php');

$archivoVehiculos = new Archivo('vehiculos.txt');
$archivoServicios = new Archivo('tiposServicios.txt');

if(isset($_POST['caso']) && !empty($_POST['caso'])){
    $caso = $_POST['caso'];

    switch($caso){
        case 'cargarVehiculo':
        $marca = $_POST['marca'];
        $patente = $_POST['patente'];
        $kms = $_POST['kms'];
        $vehiculo = new Vehiculo($marca,$patente,$kms);
        $LecturaArchivo = $archivoVehiculos->readFile();

        if($LecturaArchivo){
            if(Vehiculo::BuscarPatente($patente,$LecturaArchivo) >= 0){
                $archivoVehiculos->addObject($vehiculo);
            }
            else{
                echo("La patente ya está ingresada");
            }
        }
        else{
            $archivoVehiculos->addObject($vehiculo);
        }
        echo('Carga exitosa');
        break;
        case 'cargarTipoServicio':
        $tipo = $_POST['tipo'];
        if(Servicio::ValidarTipo($tipo)){    
            $precio = $_POST['precio'];
            $demora = $_POST['demora'];
            $LecturaArchivo = $archivoServicios->readFile();
            if($LecturaArchivo){
                $id = Servicio::ObtenerId($archivoServicios);
            }
            else{
                $id = 0;
            }
            
            $servicio = new Servicio($id,$tipo,$precio,$demora);
            $archivoServicios->addObject($servicio);
            echo('Carga exitosa');
        }
        else{
            echo('El tipo no existe');
        }
        break;
    }
}
else if(isset($_GET['caso']) && !empty($_GET['caso'])){
    $caso = $_GET['caso'];

    switch($caso){
        case 'consultarVehiculo':
        $marca = $_GET['marca'];
        $patente = $_GET['patente'];
        $LecturaArchivo = $archivoVehiculos->readFile();
        $Retorno = Vehiculo::consultarVehiculo($LecturaArchivo,$marca,$patente);
    
        break;

        case 'sacarTurno':
        $fecha = $_GET['fecha'];
        $patente = $_GET['patente'];
        $LecturaArchivo = $archivoVehiculos->readFile();
        $arrayServicios = $archivoServicios->readFile();
        $vehiculo = Vehiculo::BuscarVehiculo($patente,$LecturaArchivo);
        Servicio::sacarTurno($arrayServicios,$vehiculo,$fecha,$patente);
        break;
        case 'turnos':
        $arrayTurnos = $archivoProductos->readFile();
        Servicio::turnos($arrayTurnos);
        break;
    }
}
?>