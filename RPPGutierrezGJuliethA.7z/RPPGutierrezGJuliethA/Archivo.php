<?php

class Archivo{
    private $path;

    function __construct($path){
        $this->path = $path;
    }

    function addObject($object){
        
        $file = fopen($this->path,"a");
        fwrite($file,json_encode($object).PHP_EOL);
        fclose($file);
    }

    function readFile(){
        if(file_exists($this->path)){
            $file=fopen($this->path,'r');
            $array = array();
            while(!feof($file)){
                //de string a objeto y lopaso a un array
                $linea = fgets($file);
                array_push($array,json_decode($linea));
            }
            //$contenido = fread($file,filesize($file));
            fclose($file);
    
        return $array;
        }
        else{
            return 0;
        }
        
    }

    function writeFile($nuevoContenido){
        
        $file = fopen($this->path,"w");
        foreach($nuevoContenido as $objeto){
            fwrite($file,$objeto);
        }
        fclose($file);
    }

    function backUp($registro,$destino){
        
        $array = explode(",",$registro);
        rename(trim($array[4]),$destino);
    }
}
?>