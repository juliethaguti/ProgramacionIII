<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\empleado;
use App\Models\ORM\empleadoControler;
use App\Models\ORM\MWParaAutentificar;

include_once __DIR__ . '/../../src/app/modelAPI/MWParaAutentificar.php';
include_once __DIR__ . '/../../src/app/modelORM/empleado.php';
include_once __DIR__ . '/../../src/app/modelORM/empleadoControler.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/usuario', function () {   

      $this->post('/',empleadoControler::class . ':CargarUno');
      $this->post('/login',empleadoControler::class . ':Login');
      $this->get('/',empleadoControler::class . ':TraerUno')->add(MWParaAutentificar::class . ':VerificarUsuario');
      $this->get('s/',empleadoControler::class . ':TraerTodos')->add(MWParaAutentificar::class . ':VerificarUsuario');
      $this->post('/{legajo}[/]',empleadoControler::class . ':ModificarUno');

  });

};