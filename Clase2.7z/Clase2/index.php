<?php

include './Clases/Alumno.php';
require_once './Clases/Persona.php';
require_once './Clases/Funciones.php';

/* if(isset($_GET['nombre']) && isset($_GET['apellido'])){//Si nombre(el indice) existe,
    $nombre = $_GET['nombre'];
    $apellido = $_GET['apellido'];

    $NuevoAlumno = new Persona($nombre,$apellido);
    $datos = $NuevoAlumno->mostrar(); 
    echo $datos;
} */

/* if(isset($_POST['Cantidad'])){
    $array = array();
    $NuevoAlumno1 = new Persona("Juana","LaLoca");
    $NuevoAlumno2 = new Persona("Herodes","ElGrande");
    $NuevoAlumno3= new Persona("Napoleon","ElEnano");
    $NuevoAlumno4 = new Persona("Macri","ElGato");
    $NuevoAlumno5 = new Persona("Nicolas","ElUltimoZar");
    $NuevoAlumno6 = new Persona("Principe","Maquiavelo");
    
    array_push($array,$NuevoAlumno1);
    array_push($array,$NuevoAlumno3);
    array_push($array,$NuevoAlumno4);
    array_push($array,$NuevoAlumno5);
    array_push($array,$NuevoAlumno6);
    array_push($array, $NuevoAlumno2);

    $cantidad = $_POST['Cantidad'];
    $cont = 0;
     echo json_encode($array);
} */ 

//Json_encode json_decode de string a objeto y viceversa. Retornar en formato json siempre
//if($_server['request_method])
//crear objeto insertamos en el array, devolver alumno cargado o algo asi en formato json post -> mostrar
//Una peticion es independiente de la otra, para esto se utiliza la variable super global SESSION, que empieza con
//session_start() y termina con session_unset() o sesion_destroy(), antiguamente se utilizaba para login 
//primero distinguimos la peticion entrante, si es get o es post y luego el caso si es alumno, profesor, etc.
//fUNCIONES solo va a llamar guardar y traer
session_start();
//session_destroy();
if(!isset($_SESSION['lista'])){
    $_SESSION['lista'] = array();
    echo 'Array creado';
}
elseif($_SERVER['REQUEST_METHOD'] == 'POST'){
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];

    $alumno = new Persona($nombre,$apellido);

    $lista = Funciones::Guardar($alumno,$_SESSION['lista']);
    echo 'Alumno guardado';
    echo json_encode($lista);
}
elseif($_SERVER['REQUEST_METHOD'] == 'GET'){
    echo Funciones::TraerListado($_SESSION['lista']);
}
?>