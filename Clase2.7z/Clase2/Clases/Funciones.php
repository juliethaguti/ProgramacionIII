<?php

class Funciones{
    static function TraerListado($array){
        //get
        return json_encode($array);
    }
    
    static function Guardar($alumno, $array){
        //post
        array_push($array, $alumno);
        return $array;
    }
}

?>