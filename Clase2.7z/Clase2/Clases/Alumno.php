<?php
require_once './Clases/Persona.php';

class Alumno extends Persona{
}
?>