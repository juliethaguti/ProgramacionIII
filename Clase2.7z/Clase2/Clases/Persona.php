<?php

class Persona{

    public $nombre;
    public $apellido;

    function __construct($nombre, $apellido){
        $this->nombre = $nombre;
        $this->apellido = $apellido;
    }

    function Saludar(){
        echo "Hola ".$this->nombre; 
    }

    function mostrar(){
        /* echo "El nombre es: ".$this->nombre;
        echo "\nEl apellido es: ".$this->apellido; */
         return json_encode($this);
    }
}
?>