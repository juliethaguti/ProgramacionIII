<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Modemenu;
use App\Models\ORM\menuControler;
use App\Models\ORM\pedidoControler;
use App\Models\ORM\MWParaAutentificar;

include_once __DIR__ . '/../../src/app/modelAPI/MWParaAutentificar.php';
include_once __DIR__ . '/../../src/app/modelORM/menu.php';
include_once __DIR__ . '/../../src/app/modelORM/menuControler.php';
include_once __DIR__ . '/../../src/app/modelORM/pedido.php';
include_once __DIR__ . '/../../src/app/modelORM/pedidoControler.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/usuario', function () {   

      //$this->post('/',menuControler::class . ':TraerTodos');
      $this->post('/login',menuControler::class . ':Login');
      $this->post('/',pedidoControler::class . ':CargarUno');
      $this->get('s/',empleadoControler::class . ':TraerTodos')->add(MWParaAutentificar::class . ':VerificarUsuario');
      $this->post('/{legajo}[/]',empleadoControler::class . ':ModificarUno');

  });

};