-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-11-2019 a las 17:57:08
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `utn`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `email` varchar(50) COLLATE utf16_spanish2_ci NOT NULL,
  `clave` varchar(50) COLLATE utf16_spanish2_ci NOT NULL,
  `tipo` varchar(20) COLLATE utf16_spanish2_ci NOT NULL,
  `legajo` int(5) NOT NULL,
  `foto` varchar(250) COLLATE utf16_spanish2_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_spanish2_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`email`, `clave`, `tipo`, `legajo`, `foto`, `created_at`, `updated_at`) VALUES
('iutorioi@jkhdsjkhs.com', '$1$s3vDOAxr$ggw6rcU6ggMIPun7d1vEk1', 'alumno', 4, NULL, '2019-11-14 03:16:17', '2019-11-14 03:16:17'),
('alumno1@jkdsghk.com', 'chsCm1BS7vHsw', 'alumno', 5, '/app/fotos/5_alumno18-11.jpg', '2019-11-15 04:08:29', '2019-11-19 00:52:04'),
('iurweu@jkhdsjkhs.com', 'cuwfLKsAg9pZM', 'admin', 6, NULL, '2019-11-17 22:29:05', '2019-11-17 22:29:05'),
('profesorI@jkhdsjkhs.com', 'cuwfLKsAg9pZM', 'profesor', 7, NULL, '2019-11-18 06:18:00', '2019-11-19 03:40:13'),
('admin1@jkdsghk.com', '54x3LflfHJBn2', 'admin', 8, NULL, '2019-11-19 16:21:17', '2019-11-19 16:21:17'),
('profesor2@jkdsghk.com', '124lRP/W93.7A', 'profesor', 9, NULL, '2019-11-19 18:38:37', '2019-11-19 18:38:37');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`legajo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `legajo` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
