-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-11-2019 a las 17:56:40
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `utn`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materias`
--

CREATE TABLE `materias` (
  `id` int(5) NOT NULL,
  `nombre` varchar(100) COLLATE utf16_spanish2_ci NOT NULL,
  `cuatrimestre` int(10) NOT NULL,
  `cupos` int(5) NOT NULL,
  `legajoProfesor` int(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_spanish2_ci;

--
-- Volcado de datos para la tabla `materias`
--

INSERT INTO `materias` (`id`, `nombre`, `cuatrimestre`, `cupos`, `legajoProfesor`, `created_at`, `updated_at`) VALUES
(1, 'ingles1', 2, 28, 7, '2019-11-17 20:16:33', '2019-11-19 20:13:21'),
(2, 'programacion1', 1, 30, 9, '2019-11-17 22:30:55', '2019-11-19 18:44:24'),
(3, 'Programacion2', 1, 30, 9, '2019-11-19 19:12:04', '2019-11-19 19:16:17'),
(4, 'Programacion3', 1, 30, 0, '2019-11-19 19:12:19', '2019-11-19 19:12:19'),
(5, 'Laboratorio4', 1, 30, 9, '2019-11-19 19:12:38', '2019-11-19 19:17:01'),
(6, 'Laboratorio3', 1, 30, 0, '2019-11-19 19:12:45', '2019-11-19 19:12:45');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `materias`
--
ALTER TABLE `materias`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
