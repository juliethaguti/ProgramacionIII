<?php
namespace App\Models\ORM;
use App\Models\ORM\materia;
use App\Models\IApiControler;
use App\Models\AutentificadorJWT;

include_once __DIR__ . '/materia.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';
include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class materiaControler implements IApiControler 
{
    public function TraerTodos($request, $response, $args) {
      $tipo = $request->getAttribute('tipo');
      $token = $request->getHeader('token');
      $payload = AutentificadorJWT::ObtenerData($token[0]);

      if($tipo == 'alumno'){
        
        $idMaterias = inscripcionControler::TraerPorAlumno($payload->legajo);
        $materias = array();
        //var_dump($idMaterias);
        foreach($idMaterias as $clave=>$valor){
          foreach($valor as $idMateria=>$valor2)
          {
            $materia = materia::find($valor2);
            array_push($materias,$materia->nombre);}
        } 
        $newResponse = $response->withJson($materias,200);  
      }
      elseif($tipo == 'profesor'){
        $MateriasDicta = materia::select('nombre','cuatrimestre','cupos')->where('legajoProfesor',$payload->legajo)->get();
        $newResponse = $response->withJson($MateriasDicta, 200);
      }
      elseif ($tipo == 'admin') {
        $materiasTotal = materia::all('nombre', 'cuatrimestre','cupos');
        $newResponse = $response->withJson($materiasTotal, 200);
      }
        return $newResponse;
    }
    public function TraerUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
    	return $newResponse;
    }
   
      public function CargarUno($request, $response, $args) {
        $parametros = $request->getParsedBody();
        $materia = new materia;
        
        $materia->nombre = $parametros['nombre']; 
          $materia->cuatrimestre = $parametros['cuatrimestre'];
          $materia->cupos = $parametros['cupos']; 

          $materia->save();
          $newResponse = $response->withJson($materia, 200);  
        return $newResponse;
    }
      public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
     public function ModificarUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
		return 	$newResponse;
    }


  
}