<?php
namespace App\Models\ORM;
use App\Models\ORM\usuario;
use App\Models\IApiControler;
use App\Models\AutentificadorJWT;

include_once __DIR__ . '/usuario.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class usuarioControler implements IApiControler 
{
    
     public function TraerTodos($request, $response, $args) {
       	//return cd::all()->toJson();
        $todosLosCds=cd::all();
        $newResponse = $response->withJson($todosLosCds, 200);  
        return $newResponse;
    }
    public function TraerUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
    	return $newResponse;
    }
   
      public function CargarUno($request, $response, $args) {
        $parametros = $request->getParsedBody();
        $usuario = new usuario;
        
        if(usuarioControler::ValidarTipo($parametros['tipo'])){
          $usuario->email = $parametros['email']; 
          $usuario->clave = crypt('54321',$parametros['clave']);
          $usuario->tipo = $parametros['tipo']; 

          $usuario->save();
          $newResponse = $response->withJson($usuario, 200);  
        }
        else{
          $newResponse = $response->write("Ingrese un tipo válido");
        }
        return $newResponse;
    }
      public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
     public function ModificarUno($request, $response, $args) {
       $legajo = $args['legajo'];
       $tipo = $request->getAttribute('tipo');
       $parametros = $request->getParsedBody();
      //$uploadedFiles = $request->getUploadedFiles();
       $usuario = usuario::where('legajo', $legajo)->first();

       if($tipo == 'alumno'){
         if(isset($parametros['email']) || isset($_FILES['foto'])){
           $usuario->email = $parametros['email'];
           $foto = $_FILES['foto'];
           $nombreFoto= $usuario->legajo."_".$usuario->tipo.date("d-m");
           $usuario->foto = self::GuardarImagen($foto,$nombreFoto);
           $usuario->save();

         $newResponse = $response->withJson("Guardado exitosamente!", 200);
        }
        else{
          $newResponse = $response->withJson("No hay informacion que modificar");
         } 
       }
       elseif($tipo == 'profesor' ){
         if(isset($parametros['email']) || isset($parametros['materia'])){
         $usuario->email = $parametros['email'];
         $materia = materia::where('nombre', '=', strtolower($parametros['materia']))->first();
         $materia->legajoProfesor = $legajo;
         $usuario->save();
         $materia->save();

         $newResponse = $response->withJson("Guardado exitosamente!", 200);
        }
        else{
          $newResponse = $response->withJson("No hay informacion que modificar");
         }
       }elseif ($tipo == 'admin') {
         if($usuario->tipo == 'alumno'){
          if(isset($parametros['email']) || isset($_FILES['foto'])){
            $usuario->email = $parametros['email'];
            $foto = $_FILES['foto'];
            $nombreFoto= $usuario->legajo."_".$usuario->tipo.date("d-m");
            $usuario->foto = self::GuardarImagen($foto,$nombreFoto);
            $usuario->save();
 
          $newResponse = $response->withJson("Guardado exitosamente!", 200);
         }
         else{
          $newResponse = $response->withJson("No hay informacion que modificar");
         }
        }
        else{
          if(isset($parametros['email']) || isset($parametros['materia'])){
            $usuario->email = $parametros['email'];
            $nombre = strtolower($parametros['materia']);
            $materia = materia::where('nombre', '=', $nombre)->first();
            $materia->legajoProfesor = $legajo;
            $usuario->save();
            $materia->save();
   
            $newResponse = $response->withJson("Guardado exitosamente!", 200);
         }
        else{
           $newResponse = $response->withJson("No hay informacion que modificar");
         }
       }
      }
      else{
        $newResponse = $response->withJson("Solo usuarios registrados", 200);  
       }
       //$newResponse = $response->withJson($usuario, 200);
       return 	$newResponse;
    }

    public function Login($request, $response, $args) {
      $parametros = $request->getParsedBody();

      if(isset($parametros['clave'], $parametros['email'])){
        $pass = crypt('54321',$parametros['clave']);
        $email = $parametros['email']; 
        $usuario = usuario::where('email', $email)->first(); 

        if($usuario){
          if(hash_equals($usuario->clave,$pass)){
          $token = AutentificadorJWT::CrearToken($usuario);
          $newResponse = $response->withJson($token, 200);
          }
          else{
            $newResponse = $response->getBody()->write("La clave es incorrecta");
          }
        }
        else{
          $newResponse = $response->getBody()->write("El usuario no existe");
        }
      } 
      	return $newResponse;
    }

    static function GuardarImagen($foto, $nombreFoto){
      $ext = array_reverse(explode(".",$foto["name"]));
      $ruta = $foto["tmp_name"];
      $destino = "C:/xampp/htdocs/ModeloSegundoParcial1/src/app/fotos/".$nombreFoto.".".$ext[0];
      rename($ruta,$destino);
      return "/app/fotos/".$nombreFoto.'.'.$ext[0];
    }

    static function ValidarTipo($tipo){
      $aux = strtolower($tipo);
      if($aux == 'alumno' || $aux == 'profesor' || $aux == 'admin'){
        return true;
      }
      return false;
    }
}