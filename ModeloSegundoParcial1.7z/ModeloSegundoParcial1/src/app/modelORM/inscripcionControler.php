<?php
namespace App\Models\ORM;
use App\Models\ORM\inscripcion;
use App\Models\IApiControler;
use App\Models\AutentificadorJWT;

include_once __DIR__ . '/cd.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';
include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class inscripcionControler implements IApiControler 
{
    
     public function TraerTodos($request, $response, $args) {
       	//return cd::all()->toJson();
        $todosLosCds=cd::all();
        $newResponse = $response->withJson($todosLosCds, 200);  
        return $newResponse;
    }
    public function TraerUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
    	return $newResponse;
    }
   
      public function CargarUno($request, $response, $args) {
        
        $tipo = $request->getAttribute('tipo');
        $idMateria = $args['idMateria'];
        $token = $request->getHeader('token');
        $payload = AutentificadorJWT::ObtenerData($token[0]);
        $legajoAlumno = $payload->legajo; 
        $materia = materia::find($idMateria);
        
        if($tipo == 'alumno' && $materia->cupos > 0){
          $inscripcione = inscripcion::where('legajoAlumno',$legajoAlumno)->where('idMateria',$idMateria)->get();
            if($inscripcione->isEmpty()){
              $inscripcion = new inscripcion;
              $inscripcion->idMateria = $idMateria;
              $inscripcion->legajoAlumno = $legajoAlumno;
              $inscripcion->save();
              $materia->cupos = $materia->cupos-1;
              $materia->save();
              $newResponse = $response->withJson('inscripto', 200);
            }
            else{
            $newResponse = $response->withJson('El alumno ya está inscripto', 200);
          }
        }
        else{
            $newResponse = $response->withJson("Solo alumnos", 200);
        }  
        return $newResponse;
    }
      public function BorrarUno($request, $response, $args) {
  		//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
      	return $newResponse;
    }
     
     public function ModificarUno($request, $response, $args) {
     	//complete el codigo
     	$newResponse = $response->withJson("sin completar", 200);  
		return 	$newResponse;
    }

    static function TraerPorAlumno($idAlumno){
      $inscripcion = inscripcion::select('idMateria')->where('legajoAlumno',$idAlumno)->get();
      return $inscripcion->toArray();
    }
  
}