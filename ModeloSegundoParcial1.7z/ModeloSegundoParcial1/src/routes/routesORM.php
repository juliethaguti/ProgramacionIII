<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\usuario;
use App\Models\ORM\usuarioControler;
use App\Models\ORM\materia;
use App\Models\ORM\materiaControler;
use App\Models\ORM\inscripcion;
use App\Models\ORM\inscripcionControler;
use App\Models\ORM\MWParaAutentificar;

include_once __DIR__ . '/../../src/app/modelAPI/MWParaAutentificar.php';
include_once __DIR__ . '/../../src/app/modelORM/usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/usuarioControler.php';
include_once __DIR__ . '/../../src/app/modelORM/materia.php';
include_once __DIR__ . '/../../src/app/modelORM/materiaControler.php';
include_once __DIR__ . '/../../src/app/modelORM/inscripcion.php';
include_once __DIR__ . '/../../src/app/modelORM/inscripcionControler.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/materia', function () {   
         
        $this->post('/', materiaControler::class . ':CargarUno')->add(MWParaAutentificar::class . ':VerificarAdmin'); 
        $this->get('/lista', materiaControler::class . ':TraerTodos')->add(MWParaAutentificar::class . ':VerificarUsuario');

    });

     $app->group('/usuario', function () {   

        $this->post('/',usuarioControler::class . ':CargarUno');
        $this->post('/login',usuarioControler::class . ':Login');
        $this->post('/{legajo}[/]',usuarioControler::class . ':ModificarUno')->add(MWParaAutentificar::class . ':VerificarUsuario');
  
    });

    $app->group('/inscripcion', function () {   
         
        $this->post('/{idMateria}[/]', inscripcionControler::class . ':CargarUno')->add(MWParaAutentificar::class . ':VerificarUsuario'); 

    });
};