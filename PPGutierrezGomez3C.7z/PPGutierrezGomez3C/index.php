<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require 'vendor/autoload.php';
require_once './Pizza.php';
require_once './venta.php';

$config['addContentLenghtHeader'] = false;
$config['displayErrorDetails'] = true;

$app = new \Slim\App(['settings' => $config]);

$app->group('/pizzas',function(){
    $this->get('[/]', \Pizza::class . ':consultarPizzas');
    $this->post('/', \Pizza::class . ':cargarPizzas');
    $this->put('/', \Pizza::class . ':modificarPizza');
    $this->delete('/', \Pizza::class . ':borrarUno');
});

$app->group('/ventas',function(){
    
    $this->post('/', \Venta::class . ':cargarVentas');
    $this->get('/', \Venta::class . ':coincidenciasTipoSabor');
});

$app->run();
?>