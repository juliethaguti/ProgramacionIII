<?php
require_once './Archivo.php';

class Venta{
    private $id;
    private $email;
    private $sabor;
    private $tipo;
    private $cantidad;
    private $precioVenta;

function cargarVentas($request, $response, $args){
    $ArrayParametros = $request->getParsedBody();

    $venta = new stdclass;
    //isset($data["nombre"])?$data["nombre"]:null;
    if(isset($ArrayParametros['tipo']) && isset($ArrayParametros['cantidad']) && 
    isset($ArrayParametros['sabor']) && isset($ArrayParametros['email'])){
        $venta->tipo = $ArrayParametros['tipo'];
        $venta->cantidad = $ArrayParametros['cantidad'];
        $venta->sabor = $ArrayParametros['sabor'];
        $venta->email = $ArrayParametros['email'];
        $venta->id = Venta::ObtenerId();
        var_dump($venta);
        
        $cantidadDisponible = Pizza::PizzasDisponibles($venta->tipo, $venta->sabor);
        if($cantidadDisponible >= $venta->cantidad && $venta->cantidad > 0){
            $venta->precioVenta = $venta->cantidad*Pizza::DamePrecio($venta->tipo, $venta->sabor);
            /* Archivo::Aniadir($venta, 'Venta.txt');
            $pizzasSobrantes = $cantidadDisponible-$venta->cantidad;
            Pizza::DescontarPizzasVendidas($venta->tipo, $venta->sabor,$pizzasSobrantes); */
            $newResponse = $response->write("\nOperacion exitosa");
        }
        else{
            $newResponse = $response->write("\nNo hay cantidad suficiente de pizzas para vender");         
        }
        
        Archivo::SubirInformacion($request->getUri(),$request->getMethod());
    }
    else{
        $newResponse = $response->write("\nNo se pudo leer los datos");
    }
    
    return $response;
    
}

static function coincidenciasTipoSabor($request, $response, $args){
    $ArrayParametros = $request->getQueryParams();
    $tipo = $ArrayParametros['tipo'];
    $sabor = $ArrayParametros['sabor'];

    if(isset($tipo) || isset($sabor)){
        $list = Archivo::Leer('Venta.txt');
        for($i = 0; $i < count($list); $i++){
            if($list[$i]->sabor == $sabor && $list[$i]->tipo == $tipo){
            
                $newResponse = $response->write("\nTipo: ".$list[$i]->tipo." Cantidad: ".$list[$i]->cantidad." Sabor: ".$list[$i]->sabor." Email: ".$list[$i]->email." Id: ".$list[$i]->id." Precio Venta: ".$list[$i]->precioVenta."\n");            
            }
            elseif($list[$i]->sabor == $sabor && empty($tipo)){
            
                $newResponse = $response->write("\nTipo: ".$list[$i]->tipo." Cantidad: ".$list[$i]->cantidad." Sabor: ".$list[$i]->sabor." Email: ".$list[$i]->email." Id: ".$list[$i]->id." Precio Venta: ".$list[$i]->precioVenta."\n");

            }
            elseif($list[$i]->tipo == $tipo && empty($sabor)){
            
                $newResponse = $response->write("\nTipo: ".$list[$i]->tipo." Cantidad: ".$list[$i]->cantidad." Sabor: ".$list[$i]->sabor." Email: ".$list[$i]->email." Id: ".$list[$i]->id." Precio Venta: ".$list[$i]->precioVenta."\n");
            }
        }
    }
    else{
        $newResponse = $response->write('Datos ingresados no validos');
    }
    return $response;
}

static function ObtenerId(){
    $retorno = -1;

    if(file_exists('Venta.txt')){
        $arrayVentas = Archivo::Leer('Venta.txt');
        
        for($i = 0; $i < count($arrayVentas)-1; $i++){
            if(count($arrayVentas)-2 == $i){
                
                $retorno = $arrayVentas[$i]->id;  
            }
        }
    }
    return $retorno+1;
}


}
?>