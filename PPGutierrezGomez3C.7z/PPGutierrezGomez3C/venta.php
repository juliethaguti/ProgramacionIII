<?php
require_once './Archivo.php';

class Venta{
    private $id;
    private $email;
    private $sabor;
    private $tipo;
    private $cantidad;
    private $precioVenta;

function cargarVentas($request, $response, $args){
    $ArrayParametros = $request->getParsedBody();

    $venta = new stdclass;
    
    $venta->tipo = $ArrayParametros['tipo'];
    $venta->cantidad = $ArrayParametros['cantidad'];
    $venta->sabor = $ArrayParametros['sabor'];
    $venta->email = $ArrayParametros['email'];
    $venta->id = Venta::ObtenerId();

    
    $cantidadDisponible = Pizza::PizzasDisponibles($venta->tipo, $venta->sabor);
    if($cantidadDisponible>=$venta->cantidad){
        $venta->precioVenta = $venta->cantidad*Pizza::DamePrecio($venta->tipo, $venta->sabor);
        Archivo::Aniadir($venta, 'Venta.txt');
        $pizzasSobrantes = $cantidadDisponible-$venta->cantidad;
        Pizza::DescontarPizzasVendidas($venta->tipo, $venta->sabor,$pizzasSobrantes);
        $newResponse = $response->write("\nOperacion exitosa");
    }
    else{
        $newResponse = $response->write("\nNo hay cantidad suficiente de pizzas para vender");         
        }
    return $response;
    
}

static function ObtenerId(){
    $retorno = -1;

    if(file_exists('Venta.txt')){
        $arrayVentas = Archivo::Leer('Venta.txt');
        
        for($i = 0; $i < count($arrayVentas)-1; $i++){
            if(count($arrayVentas)-2 == $i){
                
                $retorno = $arrayVentas[$i]->id;  
            }
        }
    }
    return $retorno+1;
}


}
?>